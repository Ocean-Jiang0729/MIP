from easytorch.utils.registry import Registry

SCALER_REGISTRY = Registry("Scaler")
